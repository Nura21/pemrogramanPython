from food import Food
from drink import Drink

food1 = Food('Roti Lapis', 5)
food1.calorie_count = 330
# Tetapkan variable calorie_count milik food1 ke 330
calorie_count = Food("Roti Lapis",330)

# Panggil method calorie_info dari food1
food1.calorie_info()



#Sekarang, mari tambahkan 
#method calorie_info di dalam class Food. 
#Perlu diingat bahwa class anak dapat 
#menggunakan method yang didefinisikan di dalam class induk 
#dan method yang didefinisikan di dalam dirinya sendiri. 
#Akan tetapi, class induk tidak bisa menggunakan 
#method yang didefinisikan di dalam class anak.