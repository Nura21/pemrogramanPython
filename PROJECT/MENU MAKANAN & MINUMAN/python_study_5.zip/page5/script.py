from food import Food
from drink import Drink

food1 = Food('Roti Lapis', 5)
food1.calorie_count = 330

# Panggil method info dari food1 dan cetak nilai return
print(food1.info())
