fruits = {'apel': 'apple', 'jeruk': 'orange', 'anggur': 'grape'}

# Dengan loop for, cetak '___ adalah ___ dalam bahasa Inggris'
for i in fruits:
    print(i+" adalah "+fruits[i]+" dalam bahasa Inggris")
