# Tetapkan sebuah list string ke variable fruits
fruits=["apel","pisang","jeruk"]

# Cetak element di index 0
print(fruits[0])

# Gabungkan string dan element di index 2, dan cetak hasilnya
print("Saya suka "+fruits[2])
