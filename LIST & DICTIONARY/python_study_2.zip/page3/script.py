fruits = ['apel', 'pisang', 'jeruk']

# Tambahkan 'anggur' ke 'fruits'
fruits.append("anggur")

# Cetak 'fruits'
print(fruits)

# Perbarui element index 0
fruits[0] = "ceri"

# Cetak element index 0
print(fruits[0])

